import * as React from 'react';
import { RouteComponentProps } from 'react-router';


type CounterState = {counter:number | "loading", numbers:number[] | "loading"}
export class Counter extends React.Component<RouteComponentProps<{}>, CounterState> {
    constructor(props:any, context:any) {
        super(props, context);
        this.state = {counter:"loading", numbers:"loading"};

    }    
    async fetch_getRandomNumber() : Promise<number[]> {
        let json_res = await fetch('http://localhost:5000/api/custom/getrandomnumber',
                            {
                                method: 'get',  
                                credentials: 'include', 
                                headers: { 'content-type': 'application/json' 
                            }})
        let number = await json_res.json()
        console.log(number)
        return number

    }
    getRandomNumber(){
        this.fetch_getRandomNumber()
                .then(res => this.setState({...this.state, counter:res[0]}))
                .catch(e => console.warn(e))
    }
    getRandomNumbers(){
        this.fetch_getRandomNumber()
                .then(res => this.setState({...this.state, numbers:res}))
                .catch(e => console.warn(e))
    }

    componentWillMount(){
        this.getRandomNumber()
        this.getRandomNumbers()
    }
    public render() {
        if(this.state.counter == "loading" || this.state.numbers == "loading") return <h1>loading....</h1>
        return <div>
            <Title title={"Counter example"}/>
            <p>This is a simple example of a React component.</p>
            <p>The value of counter is: {this.state.counter}</p>
            <p>Click here to increase the number 
                <button onClick={() =>  this.state.counter != "loading" &&
                                        this.setState({...this.state, 
                                                        counter:this.state.counter + 1},
                                                    () => console.log("called after set state")) }>
                    Increase number</button>
            </p>
            <p>Click here to set a random number
                <button onClick={() => this.setState({...this.state, 
                                                        counter:"loading"}, 
                                        () => this.getRandomNumber())}>
                    Random number</button>
            </p>
            <div>
                {this.state.numbers.map(n => <p>{n}</p>)}
            </div>
        </div>;
    }

}


type TitleProps = {title:string}
export class Title extends React.Component<TitleProps, {}> {
    constructor(props:any, context:any) {
        super(props, context);
        this.state = {};
    }    
    public render(){
        return <h1>{this.props.title}</h1>
    }
}