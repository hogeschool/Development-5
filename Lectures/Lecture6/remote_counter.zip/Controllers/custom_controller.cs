using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace reactTest.Controllers
{
    [Route("api/[controller]")]
    public class CustomController : Controller
    {
        [HttpGet("GetRandomNumber")]
        public IActionResult GetRandomNumber()
        {
            var seed = new Random();
            var numbers = new int[20];
            for (int i = 0; i < 20; i++)
            {
                numbers[i] = seed.Next(0, 1000);
            }

            return Ok(numbers);
        }
    }
}
