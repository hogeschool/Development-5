import * as React from 'react';
import { RouteComponentProps } from 'react-router';

type CounterState = {
    currentCount: number | "not loaded";
}
type CounterProps = {}

export class Counter extends React.Component<RouteComponentProps<CounterProps>, CounterState> {
    constructor(props:any, context:any) {
        super(props, context);
        this.state = { currentCount: "not loaded" };
    }

    

    componentWillMount(){
        fetch(`http://localhost:5000/api/Custom/GetRandomNumber`, 
                { method: 'get', 
                  credentials: 'include', 
                  headers: { 'content-type': 'application/json' } 
                })
                .then(async res => {
                    let number:number = await res.json()
                    this.setState({...this.state, currentCount:number})
                })
                .catch(e => console.error(":(", e))
    }

    public render() {
        if(this.state.currentCount == "not loaded") return <div>
                :)
            </div>
        return <div>
            <Title title="Counter"/>

            <p>This is a simple example of a React component.</p>

            <p>Current count: <strong>{ this.state.currentCount }</strong></p>

            <button onClick={ () => 
                {
                    if(this.state.currentCount != "not loaded"){  
                        this.setState({...this.state, currentCount:this.state.currentCount + 1})
                    }
                } }>Increment</button>
        </div>;
    }

}

type TitleProps = {title:string}
                            //          props     state
export class Title extends React.Component<TitleProps, {}> {
    constructor(props:TitleProps, context:any) {
        super(props, context);
        this.state = {};
    }

    public render(){
        return <h3 className="title">{this.props.title}</h3>
    }

}



