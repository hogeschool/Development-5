using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace reactTest.Controllers
{
    [Route("api/[controller]")]
    public class CustomController : Controller
    {
        [HttpGet("GetRandomNumber")]
        public IActionResult GetRandomNumber()
        {
            var seed = new Random();
            return Ok(seed.Next(0, 1000));
        }
    }
}
